# QTrip-Dynamic

## Overview
QTrip is a travel website aimed at travellers looking for a multitude of adventures in different cities. During the course of this project,
* Created web pages using HTML and CSS and made them dynamic using JavaScript
* Improved UX with multi-select filters, image carouselsImplemented conditional rendering of page elements
* Implemented conditional rendering of page elements
* Utilized localStorage to persist user preferences at client-side
* Used JQuery to facilitate the reservation form submission
* Deployed the website using Netlify and Heroku
